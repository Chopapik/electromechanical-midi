#include <Arduino.h>
#include <SPI.h>
#include <NimBLEDevice.h>
#include <atomic>
#include <driver/ledc.h>
#include "orchestra_protocol.h"
#include "esp_ble_ota_flash.h"
using namespace orchestra;
class EspIO:public IO {
public:
 struct SpeakerOutput {uint8_t amp=0;float hz=0;} speakers[2];
 // S8550 high-side stages: HIGH is off. Preserve Arduino
 // full-on value 255 and the 256-tick period of intermediate duties.
 static uint16_t pnpDuty(uint8_t conduction){return conduction==255?0:256-conduction;}
 void speakersOffPins(){
  digitalWrite(map::vhs,HIGH);pinMode(map::vhs,OUTPUT);
  digitalWrite(map::speakerFx,HIGH);pinMode(map::speakerFx,OUTPUT);
 }
 void writeSpeaker(int channel,uint8_t conduction){
  // Raw duty avoids Arduino ledcWrite treating inverted duty 255 as 256.
  auto output=static_cast<ledc_channel_t>(channel);
  ledc_set_duty(LEDC_HIGH_SPEED_MODE,output,pnpDuty(conduction));
  ledc_update_duty(LEDC_HIGH_SPEED_MODE,output);
 }
 void atx(bool on)override{digitalWrite(map::atx,on?HIGH:LOW);pinMode(map::atx,OUTPUT);}
 void refreshSpeaker(int i){
  auto& s=speakers[i];int channel=i?2:0;
  ledcSetup(channel,s.hz>0?s.hz:20000,8);
  writeSpeaker(channel,s.amp&&s.hz>0?s.amp:0);
 }
 void updateSpeaker(int i,uint8_t amp,float hz){
  speakers[i].amp=amp;speakers[i].hz=hz;refreshSpeaker(i);
 }
 uint32_t us()override{return micros();}
 void delayUs(uint32_t n)override{delayMicroseconds(n);}
 bool track0(uint8_t pin)override{return digitalRead(pin)==LOW;}
 void outputEnable(bool on)override{digitalWrite(map::oe,on?LOW:HIGH);pinMode(map::oe,OUTPUT);}
 void beginSPI()override{
  pinMode(map::latch,OUTPUT);digitalWrite(map::latch,LOW);
  for(auto pin:map::track0)pinMode(pin,INPUT); // External pull-ups, never INPUT_PULLUP.
  SPI.begin(map::clock,-1,map::data,-1);
  speakersOffPins();
  // Channels 0/1 share a timer; channel 2 keeps FX pitch independent.
  ledcSetup(2,20000,8);writeSpeaker(2,0);ledcAttachPin(map::speakerFx,2);
  ledcSetup(0,20000,8);writeSpeaker(0,0);ledcAttachPin(map::vhs,0);
 }
 uint32_t frame(const uint8_t* bytes,size_t size)override{
  SPI.beginTransaction(SPISettings(orchestra::physical::spiClockHz,MSBFIRST,SPI_MODE0));
  digitalWrite(map::latch,LOW);for(size_t i=0;i<size;++i)SPI.transfer(bytes[i]);
  digitalWrite(map::latch,HIGH);uint32_t edge=micros();SPI.endTransaction();return edge;
 }
 void vhsFx(uint8_t amp,float hz)override{updateSpeaker(1,amp,hz);}
 void vhs(uint8_t amp,float hz)override{updateSpeaker(0,amp,hz);}
} io;
Controller ctrl(io);
// Bounded TX ring. Never block on Serial: no print in the pulse generator.
char tx[2048];size_t txRead=0,txWrite=0;bool txOverflow=false;
void queue(const char* line){size_t count=strlen(line)+1;size_t free=(txRead+sizeof(tx)-txWrite-1)%sizeof(tx);if(count>free){txOverflow=true;return;}while(*line){tx[txWrite]=*line++;txWrite=(txWrite+1)%sizeof(tx);}tx[txWrite]='\n';txWrite=(txWrite+1)%sizeof(tx);}
void drainTx(){size_t available=Serial.availableForWrite();while(available--&&txRead!=txWrite){Serial.write(uint8_t(tx[txRead]));txRead=(txRead+1)%sizeof(tx);}if(txOverflow&&txRead==txWrite){txOverflow=false;queue("ERR TX_OVERFLOW");}}

struct BleInput { uint32_t session; uint16_t length; uint8_t bytes[512]; };
struct BleReply { uint32_t session; uint16_t length; uint8_t bytes[160]; };
QueueHandle_t bleRxQueue, bleTxQueue, bleAckQueue;
QueueHandle_t bleOtaRxQueue, bleOtaTxQueue;
NimBLECharacteristic* bleTx = nullptr;
NimBLECharacteristic* bleAck = nullptr;
NimBLECharacteristic* bleOta = nullptr;
std::atomic<uint32_t> bleEpoch{0}, bleRxOverflow{0}, bleTxOverflow{0};
std::atomic<bool> bleConnected{false}, bleSubscribed{false};
std::atomic<bool> bleAckSubscribed{false};
std::atomic<bool> bleOtaSubscribed{false};
std::atomic<uint32_t> bleOtaOverflow{0};
std::atomic<int> notifyCode{-1};

// These callbacks only copy input/update transport flags. No parser, GPIO,
// Controller calls, Serial logging or notification transmission here.
class BleRxCallbacks : public NimBLECharacteristicCallbacks {
 void onWrite(NimBLECharacteristic* characteristic) override {
  const auto value = characteristic->getValue();
  if (!value.length()) return;
  const uint32_t epoch = bleEpoch.load();
  if (!bleConnected.load() || bleRxOverflow.load()==epoch) return;
  BleInput packet{}; packet.session=epoch; packet.length=value.length();
  if (packet.length>sizeof(packet.bytes)) { bleRxOverflow.store(epoch); return; }
  memcpy(packet.bytes,value.data(),packet.length);
  if (xQueueSend(bleRxQueue,&packet,0)!=pdTRUE) bleRxOverflow.store(epoch);
 }
} bleRxCallbacks;
class BleTxCallbacks : public NimBLECharacteristicCallbacks {
 void onSubscribe(NimBLECharacteristic*, ble_gap_conn_desc*, uint16_t value) override {
  bleSubscribed.store((value & 1)!=0);
 }
 void onStatus(NimBLECharacteristic*, Status, int code) override { notifyCode.store(code); }
} bleTxCallbacks;
class BleAckCallbacks : public NimBLECharacteristicCallbacks {
 void onSubscribe(NimBLECharacteristic*, ble_gap_conn_desc*, uint16_t value) override {
  bleAckSubscribed.store((value & 1)!=0);
 }
 void onStatus(NimBLECharacteristic*, Status, int code) override { notifyCode.store(code); }
} bleAckCallbacks;
class BleOtaCallbacks : public NimBLECharacteristicCallbacks {
 void onWrite(NimBLECharacteristic* characteristic) override {
  const auto value=characteristic->getValue();uint32_t epoch=bleEpoch.load();
  if(!bleConnected.load()||!value.length())return;
  BleInput packet{};packet.session=epoch;packet.length=value.length();
  if(packet.length>sizeof(packet.bytes)){bleOtaOverflow.store(epoch);return;}
  memcpy(packet.bytes,value.data(),packet.length);
  if(xQueueSend(bleOtaRxQueue,&packet,0)!=pdTRUE)bleOtaOverflow.store(epoch);
 }
 void onSubscribe(NimBLECharacteristic*, ble_gap_conn_desc*, uint16_t value) override {
  bleOtaSubscribed.store((value&1)!=0);
 }
 void onStatus(NimBLECharacteristic*,Status,int code)override{notifyCode.store(code);}
} bleOtaCallbacks;
class BleServerCallbacks : public NimBLEServerCallbacks {
 void onConnect(NimBLEServer*) override {
  bleSubscribed.store(false); bleAckSubscribed.store(false); bleOtaSubscribed.store(false); bleEpoch.fetch_add(1); bleConnected.store(true);
 }
 void onDisconnect(NimBLEServer*) override {
  bleConnected.store(false); bleSubscribed.store(false); bleAckSubscribed.store(false); bleOtaSubscribed.store(false); bleEpoch.fetch_add(1);
 }
} bleServerCallbacks;

class Replies : public ResponseSink {
public:
 void send(Transport origin,const char* line,uint32_t epoch=0) override {
  if (origin==Transport::Usb) { queue(line); return; }
  if (!bleConnected.load() || !bleSubscribed.load() || epoch!=bleEpoch.load()) return;
  // A correlated STOP acknowledgement must not sit behind obsolete telemetry.
  if (!strncmp(line,"STOPPED ",8) || !strncmp(line,"POWER OFF ",10)) xQueueReset(bleTxQueue);
  BleReply packet{}; packet.session=epoch;
  size_t count=strlen(line);
  if (count>=sizeof(packet.bytes)) { bleTxOverflow.store(epoch); return; }
  memcpy(packet.bytes,line,count);packet.bytes[count]='\n';packet.length=count+1;
  // Bounded priority mailbox. Old clients without the new subscription still
  // receive SYNCED via NUS; existing STOPPED/POWER confirmations stay on NUS.
  auto target=(!strncmp(line,"SYNCED ",7) && bleAckSubscribed.load())?bleAckQueue:bleTxQueue;
  if (xQueueSend(target,&packet,0)!=pdTRUE) bleTxOverflow.store(epoch);
 }
} replies;
class TestLed : public TestOutput {
public:
 void set(bool on) override { digitalWrite(ble::testPin,on?HIGH:LOW); }
} testLed;
CommandProtocol protocol(ctrl,replies,testLed);
ota::EspStorage otaStorage;
class OtaReplies:public ota::Replies {
 void send(const uint8_t* bytes,size_t size,uint32_t epoch)override{
  if(!bleOtaSubscribed.load()||!bleConnected.load()||epoch!=bleEpoch.load())return;
  BleReply packet{};packet.session=epoch;packet.length=size;memcpy(packet.bytes,bytes,size);
  if(xQueueSend(bleOtaTxQueue,&packet,0)!=pdTRUE)bleOtaOverflow.store(epoch);
 }
} otaReplies;
ota::Session otaSession(otaStorage,otaReplies);
void pollOta(){
 if(!bleOtaRxQueue||!bleOtaTxQueue)return;
 uint32_t epoch=bleEpoch.load();
 if(bleOtaOverflow.load()==epoch&&bleConnected.load()){
  xQueueReset(bleOtaRxQueue);otaSession.overflow();bleOtaOverflow.compare_exchange_strong(epoch,0);
 }
 otaSession.tick(micros(),epoch,!ctrl.powerOn);
 BleInput packet{};
 // Flash can block: it is only reached after authenticated BEGIN with ATX OFF.
 // One bounded packet per loop leaves STOP/USB and transport polling available.
 if(xQueueReceive(bleOtaRxQueue,&packet,0)==pdTRUE&&bleConnected.load()&&packet.session==bleEpoch.load()){
  bool wasBusy=otaSession.busy();
  otaSession.input(packet.bytes,packet.length,packet.session,micros(),!ctrl.powerOn);
  if(!wasBusy&&otaSession.busy())ctrl.allStop();
 }
 protocol.maintenance=otaSession.busy();
}

// NimBLE notify can allocate/wait inside the stack. Keep it OFF loopTask
// (motor scheduler, core 1). Only this core-0 worker transmits notifications.
bool currentBleSession(uint32_t epoch) {
 return bleConnected.load() && bleSubscribed.load() && epoch==bleEpoch.load();
}
void bleNotify(const BleReply& packet, NimBLECharacteristic* output=nullptr);
void drainOtaReplies(){
 BleReply packet{};
 while(xQueueReceive(bleOtaTxQueue,&packet,0)==pdTRUE)
  if(bleOtaSubscribed.load())bleNotify(packet,bleOta);
}
void drainBleAcks() {
 BleReply ack{};
 while(xQueueReceive(bleAckQueue,&ack,0)==pdTRUE) {
  if(bleAckSubscribed.load()) bleNotify(ack,bleAck);
 }
}
void bleNotify(const BleReply& packet, NimBLECharacteristic* output) {
 if(!output) output=bleTx;
 for(size_t offset=0;offset<packet.length && currentBleSession(packet.session);) {
  // Run only on core-0 TX worker, between telemetry fragments. ACK has its own
  // characteristic so a partial STATUS line remains byte-for-byte intact.
  if(output==bleTx){drainOtaReplies();drainBleAcks();}
  size_t count=packet.length-offset; if(count>20) count=20; // Works with MTU=23.
  notifyCode.store(-1);
  output->notify(packet.bytes+offset,count);
  // The stack reports completion asynchronously from its own task. Do not
  // retransmit a fragment just because that callback has not run yet.
  uint32_t started=millis();
  while(notifyCode.load()==-1 && currentBleSession(packet.session) && uint32_t(millis()-started)<100)
   vTaskDelay(pdMS_TO_TICKS(1));
  if(notifyCode.load()==0) offset+=count;
  // Backpressure/retry without blocking STEP, and without flooding the stack.
  vTaskDelay(pdMS_TO_TICKS(20));
 }
}
void bleTransmitTask(void*) {
 for(;;) {
  drainOtaReplies();
  drainBleAcks();
  BleReply packet{};
  if(xQueueReceive(bleTxQueue,&packet,pdMS_TO_TICKS(20))==pdTRUE) bleNotify(packet);
  uint32_t epoch=bleEpoch.load();
  if(bleTxOverflow.load()==epoch && currentBleSession(epoch) && uxQueueMessagesWaiting(bleTxQueue)==0) {
   bleTxOverflow.store(0);packet.session=epoch;
   const char* error="ERR TX_OVERFLOW\n";packet.length=strlen(error);
   memcpy(packet.bytes,error,packet.length);bleNotify(packet);
  }
 }
}
void beginBle() {
 bleRxQueue=xQueueCreate(8,sizeof(BleInput));
 bleTxQueue=xQueueCreate(32,sizeof(BleReply));
 bleAckQueue=xQueueCreate(8,sizeof(BleReply));
 bleOtaRxQueue=xQueueCreate(8,sizeof(BleInput));bleOtaTxQueue=xQueueCreate(8,sizeof(BleReply));
 if(!bleRxQueue || !bleTxQueue || !bleAckQueue || !bleOtaRxQueue || !bleOtaTxQueue) { queue("ERR BLE_INIT"); return; }
 NimBLEDevice::init(ble::name);
 auto* server=NimBLEDevice::createServer();server->setCallbacks(&bleServerCallbacks,false);
 server->advertiseOnDisconnect(true);
 auto* service=server->createService(ble::service);
 auto* rx=service->createCharacteristic(ble::rx,NIMBLE_PROPERTY::WRITE|NIMBLE_PROPERTY::WRITE_NR,512);
 rx->setCallbacks(&bleRxCallbacks);
 bleTx=service->createCharacteristic(ble::tx,NIMBLE_PROPERTY::NOTIFY,160);
 bleTx->setCallbacks(&bleTxCallbacks);
 bleAck=service->createCharacteristic(ble::ack,NIMBLE_PROPERTY::NOTIFY,20);
 bleAck->setCallbacks(&bleAckCallbacks);
 if(otaStorage.capacity()){
  bleOta=service->createCharacteristic(ota::controlUuid,NIMBLE_PROPERTY::WRITE_NR|NIMBLE_PROPERTY::NOTIFY,20);
  bleOta->setCallbacks(&bleOtaCallbacks);
  auto* data=service->createCharacteristic(ota::dataUuid,NIMBLE_PROPERTY::WRITE_NR,512);
  data->setCallbacks(&bleOtaCallbacks);
 }
 service->start();
 if(xTaskCreatePinnedToCore(bleTransmitTask,"ble-tx",4096,nullptr,1,nullptr,0)!=pdPASS) {
  queue("ERR BLE_INIT");return;
 }
 auto* advertising=NimBLEDevice::getAdvertising();
 advertising->addServiceUUID(ble::service);advertising->setScanResponse(true);advertising->start();
}
void pollBle() {
 if(!bleRxQueue) return;
 static BleInput packet{};static size_t offset=0;
 uint32_t epoch=bleEpoch.load();protocol.newBleSession(epoch);
 if(bleRxOverflow.load()==epoch && bleConnected.load()) {
  xQueueReset(bleRxQueue);packet.length=0;offset=0;protocol.bleOverflow();
  bleRxOverflow.compare_exchange_strong(epoch,0);
 }
 for(int budget=16;budget;--budget) {
  if(offset==packet.length) {
   if(xQueueReceive(bleRxQueue,&packet,0)!=pdTRUE) break;
   offset=0;
  }
  if(!bleConnected.load() || packet.session!=bleEpoch.load()) { offset=packet.length;continue; }
  protocol.newBleSession(packet.session);
  protocol.input(Transport::Ble,packet.bytes[offset++]);
 }
}
void setup(){
 io.atx(false); // Before SPI, audio, USB and BLE; external base pull-down covers reset/high-Z.
 io.speakersOffPins(); // External 10k pull-ups hold PNP off during reset/high-Z.
 digitalWrite(ble::testPin,LOW);pinMode(ble::testPin,OUTPUT);protocol.beginTest();
 ctrl.begin();Serial.begin(115200);queue("READY protocol=2 board=esp32");beginBle();
}
void loop(){
 ctrl.tick();
 pollOta();
 protocol.pollErrors();
 // Separate 16-byte budgets: neither transport can starve the other or STEP.
 for(int budget=16;budget&&Serial.available();--budget) protocol.input(Transport::Usb,Serial.read());
 ctrl.tick();pollBle();
 drainTx();
}
