"""FastAPI entrypoint for the single explicit orchestra runtime (ESP32 BLE)."""
from __future__ import annotations
import argparse
import asyncio
import contextlib
import json
import os
import sys
from urllib.parse import urlsplit
from pathlib import Path
HOST_DIR=Path(__file__).resolve().parents[1]
if str(HOST_DIR) not in sys.path: sys.path.insert(0,str(HOST_DIR))
from fastapi import FastAPI, HTTPException, UploadFile, File, WebSocket, WebSocketDisconnect
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse
from runtime.application import Application
from runtime.registry import DeviceRegistry
from web.library import MidiLibrary, MidiLibraryError, MAX_UPLOAD_BYTES
from web.contracts import validate_command

LIBRARY_HTTP_STATUS = {'invalid_name':400, 'outside_library':400, 'not_found':404,
                       'invalid_upload_name':422, 'invalid_midi':422, 'upload_too_large':413}


def _library_call(operation, *args):
    """Keep transport statuses at the controller boundary, including WS errors."""
    try:
        return operation(*args)
    except MidiLibraryError as exc:
        raise HTTPException(LIBRARY_HTTP_STATUS[exc.code], str(exc)) from exc

def create_app(*, midi_dir=None, runtime=None, connect_on_start=True, registry_path=None):
    library=MidiLibrary(Path(midi_dir or HOST_DIR.parent/'midi'))
    runtime=runtime or Application(DeviceRegistry(registry_path) if registry_path else None)
    peers={}; peer_locks={}; tasks=set(); loop=None
    async def send_peer(peer, message):
        async with peer_locks[peer]: await peer.send_json(message)
    async def send_all(message):
        for peer in list(peers.values()):
            with contextlib.suppress(Exception): await send_peer(peer,message)
    def emit(message):
        if loop: asyncio.run_coroutine_threadsafe(send_all(message),loop)
    runtime.virtual.emit=emit
    runtime.service.emit=emit
    async def broadcast():
        while True:
            await send_all({'type':'state','state':await asyncio.to_thread(runtime.snapshot)})
            await asyncio.to_thread(runtime.expire_laboratory)
            await asyncio.sleep(.05)
    async def connect_loop():
        while True:
            await asyncio.to_thread(runtime.refresh_connection,connect_on_start)
            await asyncio.sleep(2)
    @contextlib.asynccontextmanager
    async def lifespan(app):
        nonlocal loop
        loop=asyncio.get_running_loop(); runtime.start()
        workers=[asyncio.create_task(broadcast()),asyncio.create_task(connect_loop())]
        yield
        for worker in workers: worker.cancel()
        await asyncio.gather(*workers,return_exceptions=True)
        # Stop barriers need the socket receiver alive; disconnected browsers self-silence.
        await asyncio.to_thread(runtime.close)
        for task in tasks: task.cancel()
    app=FastAPI(lifespan=lifespan)
    app.state.runtime=runtime
    @app.get('/api/state')
    def state(): return runtime.snapshot()
    @app.get('/api/firmware/events')
    def firmware_events(): return list(runtime.service.events)
    @app.get('/api/monitor/raw')
    def monitor():
        return {**runtime.snapshot(),'commands':runtime.real.sent,'plan':runtime.plan.report() if runtime.plan else None}
    @app.get('/api/plan')
    def plan():
        return {'report':runtime.plan.report(),'events':[e.as_dict() for e in runtime.plan.events],
                'reinforcements':[e.as_dict() for e in runtime.plan.reinforcements]} if runtime.plan else None
    @app.get('/api/timeline')
    def timeline(): return runtime.timeline.as_dict() if runtime.timeline else None
    @app.get('/api/files')
    def files(): return library.list_files()
    @app.get('/api/files/{name}')
    def metadata(name:str): return _library_call(library.metadata,name)
    @app.post('/api/files')
    async def upload(file:UploadFile=File(...)):
        data=await file.read(MAX_UPLOAD_BYTES+1)
        path=_library_call(library.save_upload,file.filename,data)
        return {'name':path.name}
    async def command_error(peer, message, exc):
        raw=message if isinstance(message,dict) else {}
        operation=raw.get('action'); request=raw.get('requestId')
        if not isinstance(request,str): request=None
        detail=str(exc)
        lab_action={'lab_test':'uruchomienie testu','lab_update':'zmiana parametrów','lab_stop':'zatrzymanie testu'}.get(operation) if isinstance(operation,str) else None
        if lab_action:
            ident=raw.get('deviceId')
            device=runtime.registry.by_id.get(ident,{}) if isinstance(ident,str) else {}
            detail=f"{device.get('name', 'Urządzenie')} · {lab_action}: {detail}"
        with contextlib.suppress(Exception): await send_peer(peer,{'type':'error','requestId':request,'message':detail})
    async def action(peer, owner, message):
        operation=message.get('action'); request=message.get('requestId')
        try:
            runtime.require_available()
            if command_lock.locked() and operation=='service' and message.get('operation') in ('power_on','power_off','power_status','firmware','firmware_ble'):
                raise ValueError('DeviceService jest zajęty')
            def perform():
                if operation=='service' and message.get('operation') in ('power_on','power_off','power_status','firmware','firmware_ble'):
                    origin=urlsplit(peer.headers.get('origin',''))
                    if origin.scheme not in ('http','https') or origin.hostname not in ('localhost','127.0.0.1','::1') or origin.netloc!=peer.headers.get('host'):
                        raise ValueError('Sterowanie ATX i upload wymagają lokalnego połączenia z poprawnym Origin')
                runtime.require_available()
                if operation=='set_file': runtime.load(_library_call(library.resolve,message['file']))
                elif operation=='arrangement_preset': runtime.set_preset(message['preset'])
                elif operation=='play': runtime.play(owner)
                elif operation=='audio_error': runtime.audio_error(owner,message['epoch'],message.get('message','wyjście niedostępne'))
                elif operation=='pause': runtime.pause()
                elif operation=='stop': runtime.stop()
                elif operation=='seek': runtime.seek(message['position'])
                elif operation=='output': runtime.switch_output(message['mode'])
                elif operation=='speaker_waveform': runtime.set_speaker_waveform(message['deviceId'],message['waveform'])
                elif operation=='speaker_volume': runtime.set_speaker_volume(message['deviceId'],message['output'],message['value'])
                elif operation=='mute': runtime.mute(message['deviceId'],message['muted'])
                elif operation=='lab_enter': runtime.enter_laboratory(owner)
                elif operation=='lab_leave': runtime.leave_laboratory(owner)
                elif operation in ('lab_test','lab_update'):
                    runtime.test_laboratory(owner,message['deviceId'],message.get('hz',200),message.get('duration',1),message.get('modulation'),update=operation=='lab_update')
                elif operation=='lab_stop': runtime.stop_laboratory(owner,message['deviceId'])
                elif operation=='service': runtime.run_service(message['operation'],confirmed=message.get('confirmed') is True)
                else: raise ValueError('Unknown action')
            if operation=='output':
                # File loading plans outside Player's lock. Changing its output
                # must not wait behind the whole computation; Player.switch
                # still cancels playback and enforces the existing STOP barrier.
                await asyncio.to_thread(perform)
            else:
                async with command_lock:
                    await asyncio.to_thread(perform)
            await send_peer(peer,{'type':'ack','requestId':request,'state':await asyncio.to_thread(runtime.snapshot)})
        except Exception as exc:
            await command_error(peer,message,exc)
    command_lock=asyncio.Lock()
    @app.websocket('/ws')
    async def websocket(peer:WebSocket):
        import uuid,time
        await peer.accept(); owner=uuid.uuid4().hex; peers[owner]=peer; peer_locks[peer]=asyncio.Lock()
        async with peer_locks[peer]:
            await peer.send_json({'type':'hello','session':owner})
            for event in list(runtime.service.events): await peer.send_json(event)
        try:
            while True:
                raw=None
                try:
                    raw=await peer.receive_json()
                    message=validate_command(raw)
                except (ValueError,TypeError) as exc:
                    await command_error(peer,raw,exc)
                    continue
                if message.get('action')=='audio_ack': runtime.acknowledge_audio(owner,message['token'])
                elif message.get('action')=='sync':
                    runtime.heartbeat(owner)
                    await send_peer(peer,{'type':'sync','sent':message['sent'],'serverTime':time.monotonic()})
                else:
                    task=asyncio.create_task(action(peer,owner,message)); tasks.add(task); task.add_done_callback(tasks.discard)
        except WebSocketDisconnect: pass
        finally:
            peers.pop(owner,None)
            peer_locks.pop(peer,None)
            await asyncio.to_thread(runtime.disconnect,owner)
    dist=HOST_DIR.parent/'web/dist'
    if dist.exists():
        @app.get('/settings',include_in_schema=False)
        def settings_page(): return FileResponse(dist/'index.html')
        app.mount('/',StaticFiles(directory=dist,html=True),name='web')
    return app

def main(argv=None):
    import uvicorn
    parser=argparse.ArgumentParser()
    parser.add_argument('--host',default='127.0.0.1'); parser.add_argument('--port',type=int,default=8000)
    parser.add_argument('--midi-dir',type=Path,default=HOST_DIR.parent/'midi')
    parser.add_argument('--registry',type=Path,default=None)
    parser.add_argument('--offline',action='store_true',default=os.getenv('ORCHESTRA_OFFLINE')=='1',help='Disable BLE discovery; output still starts REAL')
    args=parser.parse_args(argv)
    uvicorn.run(create_app(midi_dir=args.midi_dir,registry_path=args.registry,connect_on_start=not args.offline),host=args.host,port=args.port)
    return 0
if __name__=='__main__': raise SystemExit(main())
