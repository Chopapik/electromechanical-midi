"""Compile the production dispatcher: USB/BLE share parser, not motor state copies."""
import shutil
import subprocess
import tempfile
import unittest
from pathlib import Path
from test_esp32_firmware import SOURCE as CORE_SOURCE, ROOT

SOURCE = CORE_SOURCE.split('int main(')[0].replace('"orchestra_core.h"', '"orchestra_protocol.h"') + r'''
struct Reply { Transport origin; std::string text; uint32_t session; };
struct Sink: ResponseSink {
 std::vector<Reply> replies;
 void send(Transport origin,const char* line,uint32_t session=0)override { replies.push_back({origin,line,session}); }
};
struct Led: TestOutput { bool on=true; int writes=0; void set(bool value)override{on=value;++writes;} };
void feed(CommandProtocol& p,Transport origin,const std::string& text){for(uint8_t ch:text)p.input(origin,ch);}
int main(int argc,char** argv){
 std::string c=argv[1];Fake io;Controller ctrl(io);ctrl.begin();Sink sink;Led led;CommandProtocol p(ctrl,sink,led);p.beginTest();p.newBleSession(1);if(c!="power")ctrl.command("POWER ON");
 if(c=="power"){
  feed(p,Transport::Usb,"POWER STATUS\n");assert(sink.replies.back().text=="POWER STATUS OFF gpio19=0"&&sink.replies.back().origin==Transport::Usb);
  feed(p,Transport::Ble,"POWER ON 42\n");assert(io.atxOn&&sink.replies.back().text=="POWER ON gpio19=1 token=42"&&sink.replies.back().session==1);
  feed(p,Transport::Usb,"POWER OFF 43\n");assert(!io.atxOn&&sink.replies.back().text=="POWER OFF gpio19=0 token=43");
  feed(p,Transport::Ble,"FDD ALL HOME\n");assert(sink.replies.back().text=="ERR POWER_OFF");
  for(auto text:{"POWER ON bad","POWER OFF 12345678901","POWER ON 1 EXTRA","POWER INVALID","POWER"}){p.execute(Transport::Ble,text);assert(sink.replies.back().text=="ERR COMMAND"&&!io.atxOn);}
 }else if(c=="led"){
  assert(!led.on&&!p.testOn&&led.writes==1);
  p.execute(Transport::Ble,"TEST ON");assert(led.on&&sink.replies.back().text=="TEST ON");
  p.execute(Transport::Usb,"TEST OFF");assert(!led.on&&sink.replies.back().text=="TEST OFF");
  p.execute(Transport::Ble,"TEST TOGGLE");assert(led.on);
  p.execute(Transport::Usb,"TEST TOGGLE");assert(!led.on);
 }else if(c=="led_status"){
  p.execute(Transport::Ble,"TEST ON");int writes=led.writes;
  p.execute(Transport::Usb,"TEST STATUS");assert(led.on&&led.writes==writes&&sink.replies.back().text=="TEST ON");
  size_t frames=io.edges.size();p.execute(Transport::Usb,"TEST INVALID");
  assert(led.on&&led.writes==writes&&sink.replies.back().text=="ERR COMMAND"&&io.edges.size()==frames);
 }else if(c=="sync"){
  uint32_t previous=ctrl.lastCommand;size_t edges=io.edges.size();io.now+=1000;
  feed(p,Transport::Ble,"SYNC 1234567890\n");
  assert(sink.replies.back().text=="SYNCED 1234567890"&&sink.replies.back().session==1);
  feed(p,Transport::Usb,"SYNC 0\n");
  assert(sink.replies.back().text=="SYNCED 0"&&sink.replies.back().origin==Transport::Usb);
  assert(ctrl.lastCommand==previous&&io.edges.size()==edges);
  for(const char* bad:{"SYNC ","SYNC invalid","SYNC -1","SYNC 12345678901","SYNC 1 EXTRA"}){
   p.execute(Transport::Ble,bad);assert(sink.replies.back().text=="ERR VALUE");
  }
  ctrl.fdd[0].homed=true;
  feed(p,Transport::Ble,"FDD 1 PLAY 220\nSYNC 23\n");
  assert(ctrl.fdd[0].playing&&sink.replies.back().text=="SYNCED 23");
  feed(p,Transport::Ble,"ALL STOP 9\nSYNC 24\n");
  assert(!ctrl.fdd[0].playing&&sink.replies[sink.replies.size()-2].text=="STOPPED 9"&&sink.replies.back().text=="SYNCED 24");
  feed(p,Transport::Ble,"FDD 1 PLAY 220\n");assert(ctrl.fdd[0].playing);
  for(int i=0;i<31;++i){io.now+=100000;feed(p,Transport::Ble,"SYNC 24\n");ctrl.tick();}
  assert(!ctrl.fdd[0].playing); // SYNC receipts cannot keep old motion alive.
  feed(p,Transport::Ble,"SY");p.newBleSession(2);feed(p,Transport::Ble,"NC 25\n");
  assert(sink.replies.back().text=="ERR COMMAND");
  p.bleOverflow();feed(p,Transport::Ble,"\nSYNC 26\n");
  assert(sink.replies.back().text=="ERR RX_OVERFLOW");
  p.newBleSession(3);feed(p,Transport::Ble,"SYNC 27\n");
  assert(sink.replies.back().text=="SYNCED 27"&&sink.replies.back().session==3);
 }else if(c=="ping"){
  feed(p,Transport::Usb,"PING\n");feed(p,Transport::Ble,"PING\n");
  assert(sink.replies.size()==2&&sink.replies[0].origin==Transport::Usb&&sink.replies[1].origin==Transport::Ble);
  assert(sink.replies[0].text=="PONG"&&sink.replies[1].text=="PONG");
  assert(sink.replies[0].session==0&&sink.replies[1].session==1);
 }else if(c=="status"){
  p.execute(Transport::Usb,"STATUS");size_t n=sink.replies.size();assert(n==17);
  p.execute(Transport::Ble,"STATUS");assert(sink.replies.size()==2*n);
  for(size_t i=0;i<n;++i){assert(sink.replies[i].origin==Transport::Usb&&sink.replies[i+n].origin==Transport::Ble);assert(sink.replies[i].text==sink.replies[i+n].text);}
  assert(sink.replies[n].text=="STATUS BEGIN"&&sink.replies.back().text=="STATUS END");
  assert(sink.replies[10].text=="STATUS SLED 1 enabled=0 playing=0 hz=0.00 position=0 dir=fwd soft_min=0 soft_max=0 rate=0 target=0 pos_conf=LOW ramp=0");
  ctrl.sled[0].position=73;ctrl.sled[0].forward=false;
  p.execute(Transport::Ble,"STATUS");
  assert(sink.replies[2*n+10].text=="STATUS SLED 1 enabled=0 playing=0 hz=0.00 position=73 dir=rev soft_min=0 soft_max=0 rate=0 target=0 pos_conf=LOW ramp=0");
 }else if(c=="status_bounds"){
  io.now=4294960000u;
  for(auto& f:ctrl.fdd){f.hz=500;f.awaySteps=255;f.directionAway=false;}
  for(auto& s:ctrl.sled){s.hz=10000;s.softMax=0;s.position=INT32_MIN;s.currentStepRate=-10000;s.targetStepRate=10000;}
  for(auto& h:ctrl.hdd){h.state=Hdd::Park;h.deadline=4294960000u;}
  p.execute(Transport::Usb,"STATUS");size_t bytes=0;
  for(auto r:sink.replies){assert(r.text.size()<159);bytes+=r.text.size()+1;}
  assert(bytes<2048);assert(sink.replies.back().text=="STATUS END");
 }else if(c=="fragment"){
  feed(p,Transport::Ble,"TE");feed(p,Transport::Ble,"ST O");assert(!led.on&&sink.replies.empty());
  feed(p,Transport::Ble,"N\r");assert(!led.on);feed(p,Transport::Ble,"\nPING\nTEST OFF\n");
  assert(!led.on&&sink.replies.size()==3&&sink.replies[1].text=="PONG");
 }else if(c=="separate_lines"){
  feed(p,Transport::Ble,"PI");feed(p,Transport::Usb,"TEST O");
  feed(p,Transport::Ble,"NG\n");assert(!led.on&&sink.replies.back().origin==Transport::Ble);
  feed(p,Transport::Usb,"N\n");assert(led.on&&sink.replies.back().origin==Transport::Usb);
 }else if(c=="line_overflow"){
  feed(p,Transport::Ble,std::string(110,'X')+"TEST ON\nPING\n");
  assert(!led.on&&sink.replies.size()==2&&sink.replies[0].text=="ERR LINE_TOO_LONG"&&sink.replies[1].text=="PONG");
 }else if(c=="rx_overflow"){
  feed(p,Transport::Ble,"TEST O");p.bleOverflow();feed(p,Transport::Ble,"N\nPING\n");
  assert(!led.on&&sink.replies.size()==2&&sink.replies[0].text=="ERR RX_OVERFLOW"&&sink.replies[1].text=="PONG");
 }else if(c=="session"){
  feed(p,Transport::Ble,"TEST O");feed(p,Transport::Usb,"PI");p.newBleSession(2);
  feed(p,Transport::Ble,"N\n");assert(!led.on&&sink.replies.back().text=="ERR COMMAND");
  feed(p,Transport::Usb,"NG\n");assert(sink.replies.back().text=="PONG");
  feed(p,Transport::Ble,"TEST ON\n");assert(led.on&&sink.replies.back().session==2);
 }else if(c=="nul"){
  feed(p,Transport::Ble,std::string("TEST ON\0",8)+"\nPING\n");
  assert(!led.on&&sink.replies[0].text=="ERR COMMAND"&&sink.replies.back().text=="PONG");
 }else if(c=="shared_motor"){
  ctrl.fdd[0].homed=true;p.execute(Transport::Ble,"FDD 1 PLAY 220");assert(ctrl.fdd[0].playing&&ctrl.fdd[0].hz==220);
  p.execute(Transport::Usb,"FDD 1 STOP");assert(!ctrl.fdd[0].playing&&sink.replies.empty());
  p.execute(Transport::Usb,"HDD 2 HIT");assert(ctrl.hdd[1].state==Hdd::Park);
  p.execute(Transport::Ble,"VHS AMP 25");assert(ctrl.amp==25);
  p.execute(Transport::Ble,"ALL STOP");assert(ctrl.hdd[1].state==Hdd::Idle&&ctrl.amp==0&&io.previous==0x5555);
 }else if(c=="error_routing"){
  p.execute(Transport::Ble,"FDD 1 PLAY 220");assert(sink.replies.back().origin==Transport::Ble&&sink.replies.back().text=="ERR NOT_HOMED");
  p.execute(Transport::Ble,"FDD 1 HOME");p.execute(Transport::Usb,"FDD 2 HOME");
  io.now+=2000001;ctrl.lastCommand=io.now;ctrl.tick();p.newBleSession(3);p.pollErrors();
  assert(sink.replies[1].origin==Transport::Ble&&sink.replies[1].session==1&&sink.replies[1].text=="ERR HOME_FAILED FDD=1");
  assert(sink.replies[2].origin==Transport::Usb&&sink.replies[2].text=="ERR HOME_FAILED FDD=2");
  p.pollErrors();assert(sink.replies.size()==3);
 }else if(c=="stop_ack"){
  for(auto& f:ctrl.fdd){f.homed=true;f.play(220,io);}
  ctrl.hdd[0].hit(ctrl.bus);ctrl.amp=100;
  p.execute(Transport::Ble,"ALL STOP 42");
  for(auto& f:ctrl.fdd)assert(!f.playing&&!f.homing);
  assert(ctrl.hdd[0].state==Hdd::Idle&&ctrl.amp==0);
  assert(sink.replies.back().text=="STOPPED 42"&&sink.replies.back().origin==Transport::Ble&&sink.replies.back().session==1);
  p.execute(Transport::Usb,"ALL STOP 43");assert(sink.replies.back().text=="STOPPED 43"&&sink.replies.back().origin==Transport::Usb);
  p.execute(Transport::Ble,"ALL STOP invalid");assert(sink.replies.back().text=="ERR VALUE");
 }else if(c=="extended_status"){
  p.execute(Transport::Ble,"DIAG FDD");assert(sink.replies.size()==6);
  assert(sink.replies.front().text=="DIAG FDD BEGIN"&&sink.replies.back().text=="DIAG FDD END");
  for(int i=0;i<4;++i){auto r=sink.replies[i+1];assert(r.origin==Transport::Ble&&r.session==1);assert(r.text.find("DIAG FDD "+std::to_string(i+5)+" enabled=0 homed=0 playing=0 homing=0")==0);assert(r.text.size()<159);}
  assert(io.previous==0x5555);sink.replies.clear();p.execute(Transport::Usb,"STATUS");assert(sink.replies.size()==17);
  for(auto r:sink.replies)assert(r.text.find("STATUS FDD 5")==std::string::npos&&r.text.find("DIAG FDD")==std::string::npos);
  sink.replies.clear();p.execute(Transport::Usb,"FDD 8 ENABLE 1");p.execute(Transport::Usb,"FDD 8 HOME");
  io.active[7]=true;ctrl.tick();p.execute(Transport::Usb,"DIAG FDD");
  assert(sink.replies[4].text.find("DIAG FDD 8 enabled=1 homed=1 playing=0 homing=0")==0);assert(sink.replies[4].text.find("track0=1 raw=0")!=std::string::npos);
 }else if(c=="four_sled_status"){
  p.execute(Transport::Usb,"SLED 4 ENABLE 1");p.execute(Transport::Usb,"SLED 4 PLAY 220");
  p.execute(Transport::Usb,"STATUS");assert(sink.replies.size()==17);
  int count=0;for(auto r:sink.replies){if(r.text.find("STATUS SLED ")==0)++count;assert(r.origin==Transport::Usb);}
  assert(count==4);bool found=false;for(auto r:sink.replies)if(r.text.find("STATUS SLED 4 enabled=1 playing=1 hz=220.00")==0)found=true;assert(found);
  sink.replies.clear();
  for(int ordinal=map::sledCount+1;ordinal<=map::sledCount+2;++ordinal){
   std::string command="SLED "+std::to_string(ordinal)+" ENABLE 1";
   p.execute(Transport::Ble,command.c_str());assert(sink.replies.back().text=="ERR ID"&&sink.replies.back().origin==Transport::Ble);
  }
  p.execute(Transport::Ble,"ALL STOP 44");assert(!ctrl.sled[3].playing&&io.previous==0x5555&&sink.replies.back().text=="STOPPED 44");
 }else if(c=="extended_error_routing"){
  for(int i=5;i<=8;++i){char cmd[50];snprintf(cmd,sizeof(cmd),"FDD %d ENABLE 1",i);p.execute(Transport::Usb,cmd);snprintf(cmd,sizeof(cmd),"FDD %d HOME",i);p.execute(i%2?Transport::Ble:Transport::Usb,cmd);}
  p.newBleSession(7);io.now+=2000001;ctrl.lastCommand=io.now;ctrl.tick();p.pollErrors();assert(sink.replies.size()==4);
  for(int i=0;i<4;++i){auto r=sink.replies[i];assert(r.text=="ERR HOME_FAILED FDD="+std::to_string(i+5));assert(r.origin==(i%2?Transport::Usb:Transport::Ble));assert(r.session==1);}
  p.pollErrors();assert(sink.replies.size()==4);
 }else if(c=="diag"){
  for(int bit=0;bit<48;++bit){char cmd[40];snprintf(cmd,sizeof(cmd),"DIAG BIT %d",bit);p.execute(Transport::Ble,cmd);assert(io.previous==(uint64_t(1)<<bit)&&sink.replies.back().origin==Transport::Ble);}
  const uint64_t old=io.previous;
  for(const char* bad:{"DIAG BIT 48","DIAG BIT 255","DIAG BIT -1","DIAG BIT ","DIAG BIT invalid"}){p.execute(Transport::Usb,bad);assert(sink.replies.back().text=="ERR VALUE"&&io.previous==old);}
  p.execute(Transport::Usb,"ALL STOP");assert((io.previous&0x5555)==0x5555);
 }else assert(false);
}
'''


class Esp32ProtocolTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        compiler = shutil.which('clang++') or shutil.which('g++')
        if not compiler:
            raise RuntimeError('C++ compiler required for firmware protocol tests')
        cls.directory = tempfile.TemporaryDirectory()
        source = Path(cls.directory.name) / 'protocol.cpp'
        source.write_text(SOURCE)
        cls.binary = source.with_suffix('')
        subprocess.run([compiler, '-std=c++11', '-I', str(ROOT/'firmware/controller/include'),
                        str(source), '-o', str(cls.binary)], check=True, capture_output=True)

    @classmethod
    def tearDownClass(cls):
        cls.directory.cleanup()

for case in ('power','led', 'led_status', 'ping', 'sync', 'status','status_bounds', 'fragment', 'separate_lines',
             'line_overflow', 'rx_overflow', 'session', 'nul', 'shared_motor', 'error_routing', 'extended_status', 'four_sled_status', 'extended_error_routing', 'diag', 'stop_ack'):
    def run(self, case=case):
        subprocess.run([str(self.binary), case], check=True, capture_output=True)
    setattr(Esp32ProtocolTests, 'test_'+case, run)
