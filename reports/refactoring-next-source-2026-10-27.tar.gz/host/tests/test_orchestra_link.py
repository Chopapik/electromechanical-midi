import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import unittest
from unittest.mock import Mock, patch
from orchestra_link import OrchestraLink, parse_fdd_diagnostics, parse_status
from playback.hardware import bind_devices, build_commands
from playback.orchestra import esp32_startup_config
from playback.virtual import VirtualDeviceInstance
from firmware import run_firmware


class ProtocolTests(unittest.TestCase):
    def link(self):
        link = OrchestraLink.__new__(OrchestraLink)
        link.send = Mock()
        link.protocol_version = 2
        link.device_status = {}
        link.controller_status = {}
        link._status_lines = None
        link._fdd_diagnostic_lines = None
        link.status_generation = 0
        link.extended_status_generation = 0
        return link

    def test_commands(self):
        l = self.link()
        l.fdd_play(4,220); l.fdd_home(3); l.fdd_stop(2)
        l.hdd_hit(4); l.hdd_stop(2); l.sled_play(3,196); l.sled_stop(1)
        l.vhs_amp(200); l.vhs_freq(164.81); l.vhs_stop(); l.ping(); l.status(); l.fdd_status(); l.all_stop()
        self.assertEqual([c.args[0] for c in l.send.call_args_list], [
            'FDD 4 PLAY 220.00','FDD 3 HOME','FDD 2 STOP','HDD 4 HIT','HDD 2 STOP',
            'SLED 3 PLAY 196.00','SLED 1 STOP',
            'VHS AMP 200','VHS FREQ 164.81','VHS STOP','PING','STATUS','DIAG FDD','ALL STOP'])
        for id in (0,9,True,'1'):
            with self.assertRaises(ValueError): l.fdd_home(id)

    def test_stop_waits_for_matching_execution_ack(self):
        l = self.link()
        l.poll_lines = Mock(side_effect=[['STOPPED 99'], ['STOPPED 42']])
        with patch('orchestra_link.time.monotonic_ns', return_value=42):
            self.assertTrue(l.all_stop_confirmed(timeout=.1))
        l.send.assert_called_once_with('ALL STOP 42')
        self.assertEqual(l.poll_lines.call_count, 2)

    def test_stop_ack_timeout_is_not_a_serial_disconnect(self):
        from orchestra_link import StopConfirmationError
        l = self.link(); l.poll_lines = Mock(return_value=[])
        with self.assertRaises(StopConfirmationError): l.all_stop_confirmed(timeout=.01)

    def test_status_complete_only(self):
        lines = ['STATUS BEGIN','STATUS CTRL board=esp32 ready=1','STATUS FDD 4 enabled=1 homed=1 homing=0',
                 'STATUS HDD 3 enabled=0 busy=0','STATUS VHS enabled=1 amp=38 hz=196','STATUS END']
        parsed = parse_status(lines)
        self.assertEqual(parsed['devices']['FDD:4']['homed'],'1')
        with self.assertRaises(ValueError): parse_status(lines[:-1])
        l = self.link()
        with patch('floppy_link.FloppyLink.poll_lines', side_effect=[lines[:-1],lines[-1:]]):
            l.poll_lines(); self.assertEqual(l.device_status,{})
            l.poll_lines(); self.assertEqual(l.device_status,parsed['devices'])
            self.assertIsNotNone(l.status_observed_at)

    def test_extended_fdd_status_merges_atomically_with_standard_status(self):
        base = ['STATUS BEGIN','STATUS CTRL board=esp32 ready=1',
                'STATUS FDD 1 enabled=1 homed=1 homing=0','STATUS END']
        diagnostic = ['DIAG FDD BEGIN'] + [
            f'DIAG FDD {i} enabled=1 homed=1 homing=0 track0=1' for i in range(5,9)
        ] + ['DIAG FDD END']
        self.assertEqual(set(parse_fdd_diagnostics(diagnostic)),
                         {f'FDD:{i}' for i in range(5,9)})
        l = self.link()
        with patch('floppy_link.FloppyLink.poll_lines',
                   side_effect=[diagnostic[:-1], diagnostic[-1:], base]):
            l.poll_lines()
            self.assertEqual(l.device_status, {})
            l.poll_lines()
            self.assertEqual(l.extended_status_generation, 1)
            l.poll_lines()
        self.assertEqual(set(l.device_status), {'FDD:1'} | {f'FDD:{i}' for i in range(5,9)})
        with self.assertRaises(ValueError):
            parse_fdd_diagnostics(diagnostic[:-1])

    def test_ready_negotiates_v2(self):
        l=self.link();l.protocol_version=1
        with patch('floppy_link.FloppyLink.poll_lines', return_value=['READY protocol=2 board=esp32']):
            l.poll_lines()
        self.assertEqual(l.protocol_version,2)

    def test_preset_and_stable_ids(self):
        config=esp32_startup_config()
        self.assertEqual(len(config['devices']),13)
        devices=[VirtualDeviceInstance.parse(d) for d in config['devices']]
        self.assertTrue(all(not d.enabled for d in devices if d.type == 'DVD_SLED'))
        devices[0].enabled=False
        bound,unmapped=bind_devices(devices,2)
        self.assertNotIn('fdd:1',bound)
        self.assertEqual(bound['fdd:2'].id,devices[1].id)
        self.assertEqual(len(bound),8)
        self.assertEqual(unmapped,[])
        _,unmapped=bind_devices(devices,1)
        self.assertTrue(unmapped)

    def test_build_target(self):
        with patch('firmware.prepare_build'),patch('firmware.subprocess.run',return_value=Mock(returncode=0,stdout='built')) as run:
            run_firmware('pio',target='esp32')
        self.assertIn('esp32',run.call_args.args[0])
        with self.assertRaises(ValueError): run_firmware('pio',target='bad')

    def test_v2_home_requires_status_not_ready(self):
        l=self.link()
        lines=['STATUS BEGIN','STATUS CTRL board=esp32 ready=1','STATUS FDD 1 enabled=1 homed=1 homing=0','STATUS END',
               'DIAG FDD BEGIN']+[f'DIAG FDD {i} enabled=0 homed=0 homing=0' for i in range(5,9)]+['DIAG FDD END']
        with patch('floppy_link.FloppyLink.poll_lines',return_value=lines):
            self.assertTrue(l.wait_homed(timeout=.2,echo=lambda _:None))
        lines[2]='STATUS FDD 1 enabled=1 homed=0 homing=1'
        with patch('floppy_link.FloppyLink.poll_lines',return_value=lines):
            self.assertFalse(l.wait_homed(timeout=.02,echo=lambda _:None))



    def test_incomplete_status_cannot_confirm_homing(self):
        l=self.link()
        with patch('floppy_link.FloppyLink.poll_lines',return_value=['STATUS BEGIN','STATUS CTRL ready=1','STATUS END']):
            self.assertFalse(l.wait_homed(timeout=.02,echo=lambda _:None))


    def test_hardware_event_ids_and_disabled_filter(self):
        from types import SimpleNamespace
        a=VirtualDeviceInstance.parse({'id':'fdd1','type':'FDD','mode':'real','enabled':False})
        b=VirtualDeviceInstance.parse({'id':'fdd2','type':'FDD','mode':'real'})
        h=VirtualDeviceInstance.parse({'id':'hdd1','type':'HDD_VCM','mode':'real'})
        bound,_=bind_devices([a,b,h],2)
        event=lambda id: SimpleNamespace(device=id,time=0,duration=.2,hz=220)
        commands=build_commands(SimpleNamespace(events=[event('fdd1'),event('fdd2'),event('hdd1')]),bound)
        self.assertEqual([(c.kind,c.lane) for c in commands],[('play','fdd:2'),('stop','fdd:2'),('hit','hdd:1')])
