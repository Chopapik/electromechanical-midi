"""NUS byte transport beneath the existing OrchestraLink command/status parser."""
import asyncio
import contextlib
import os
import select
import socket
import secrets
import threading
import time

from floppy_link import SerialLinkError
from orchestra_link import OrchestraLink
from ble_diagnostics import WriteHistory, LoopTiming
from ble_configuration import validate_configuration, command_groups
import ble_ota

NAME = 'Electromechanical-MIDI'
SERVICE = '6E400001-B5A3-F393-E0A9-E50E24DCCA9E'
RX = '6E400002-B5A3-F393-E0A9-E50E24DCCA9E'
TX = '6E400003-B5A3-F393-E0A9-E50E24DCCA9E'
ACK = '6E400004-B5A3-F393-E0A9-E50E24DCCA9E'
APPLICATION_ACK_TIMEOUT = .250


class BleBytes:
    """One BLE session. Never replay pending commands into a new connection."""
    def __init__(self, scanner=None, client_factory=None, timeout=20):
        if scanner is None:
            from bleak import BleakScanner, BleakClient
            scanner, client_factory = BleakScanner, BleakClient
        self._scanner, self._factory = scanner, client_factory
        self._buffer = bytearray()
        self._lock = threading.Lock()
        self._error = None
        self._ready = threading.Event()
        self._closed = False
        self._write_history = WriteHistory()
        self._loop = asyncio.new_event_loop()
        self._thread = threading.Thread(target=self._run, name='orchestra-ble', daemon=True)
        self._thread.start()
        if not self._ready.wait(timeout):
            self.close()
            raise SerialLinkError('BLE: timeout podczas szukania/łączenia ' + NAME)
        self._check()

    def _run(self):
        asyncio.set_event_loop(self._loop)
        try:
            self._task = self._loop.create_task(self._session())
            self._loop.run_until_complete(self._task)
        except asyncio.CancelledError:
            pass
        except Exception as exc:
            self._error = SerialLinkError(f'BLE: {exc}')
        finally:
            self._closed = True
            self._ready.set()
            # Disconnect may happen while a writer waits for an execution ACK.
            # Resolve/cancel those futures before closing their owning loop.
            pending = asyncio.all_tasks(self._loop)
            for task in pending: task.cancel()
            if pending:
                self._loop.run_until_complete(asyncio.gather(*pending, return_exceptions=True))
            self._loop.close()

    async def _session(self):
        self._end = asyncio.Event()
        device = await self._scanner.find_device_by_filter(
            lambda device, adv: (adv.local_name or device.name) == NAME,
            timeout=6, service_uuids=[SERVICE])
        if device is None:
            raise SerialLinkError('Nie znaleziono ' + NAME)
        def disconnected(_client):
            self._error = SerialLinkError('BLE: disconnected')
            self._end.set()
        async with self._factory(device, disconnected_callback=disconnected, timeout=10) as client:
            self._client = client
            self._write_lock = asyncio.Lock()
            # One ordinary ATT write, never a long/prepared write. Keep the
            # conservative 20-byte fallback for clients reporting MTU=23.
            self.write_size = max(20, min(512, getattr(client, 'mtu_size', 23) - 3))
            self._application_ack = False
            await client.start_notify(TX, self._notification)
            services = getattr(client, 'services', None)
            self.supports_ota = services is not None and services.get_characteristic(ble_ota.CONTROL) is not None and services.get_characteristic(ble_ota.DATA) is not None
            if services is not None and services.get_characteristic(ACK) is not None:
                # New firmware advertises a separate execution-barrier stream.
                # Do not just switch to unconfirmed writes on legacy firmware.
                self._ack_buffer = bytearray()
                self._pending_ack = None
                self._ack_sequence = secrets.randbelow(1_000_000_000)+1
                rx = services.get_characteristic(RX)
                self.write_size = min(self.write_size, rx.max_write_without_response_size)
                if self.write_size < 20:
                    raise SerialLinkError('BLE: invalid write-without-response capacity')
                await client.start_notify(ACK, self._ack_notification)
                await self._ack_exchange(b'')  # Read-only capability verification.
                self._application_ack = True
            self._loop_timing = LoopTiming()
            async def monitor_loop():
                while True:
                    await asyncio.sleep(self._loop_timing.interval)
                    self._loop_timing.tick()
            monitor = asyncio.create_task(monitor_loop())
            self._ready.set()
            try:
                await self._end.wait()
            finally:
                monitor.cancel()
                with contextlib.suppress(asyncio.CancelledError): await monitor

    def _notification(self, _characteristic, data):
        with self._lock:
            if len(self._buffer) + len(data) > 65536:
                self._error = SerialLinkError('BLE: przepełnienie bufora RX')
                self._end.set()
                return
            self._buffer.extend(data)

    def _ack_notification(self, _characteristic, data):
        self._ack_buffer.extend(data)
        if len(self._ack_buffer) > 128:
            self._error = SerialLinkError('BLE: execution ACK overflow')
            self._end.set()
            return
        while b'\n' in self._ack_buffer:
            line, _, rest = self._ack_buffer.partition(b'\n')
            self._ack_buffer[:] = rest
            pending = self._pending_ack
            # A duplicate/old/wrong token never releases the next packet.
            if pending and line.rstrip(b'\r') == b'SYNCED '+pending[0]:
                if not pending[1].done(): pending[1].set_result(None)

    async def _ack_exchange(self, data, trace=None):
        self._ack_sequence += 1
        if self._ack_sequence > 9_999_999_999:
            raise SerialLinkError('BLE: execution ACK sequence exhausted')
        token = str(self._ack_sequence).encode('ascii')
        future = asyncio.get_running_loop().create_future()
        self._pending_ack = (token, future)
        async def exchange():
            framed = data+b'SYNC '+token+b'\n'
            for offset in range(0, len(framed), self.write_size):
                if trace: trace.mark('gatt_started')
                await self._client.write_gatt_char(RX, framed[offset:offset+self.write_size], response=False)
                if trace: trace.fragment_finished()
            if trace: trace.mark('ack_wait')
            await future
            if trace: trace.mark('ack_received')
        try:
            await asyncio.wait_for(exchange(), APPLICATION_ACK_TIMEOUT)
        except asyncio.TimeoutError as exc:
            raise SerialLinkError('BLE realtime overrun: execution ACK timeout (250 ms); playback stopped') from exc
        finally:
            self._pending_ack = None

    def _ack_groups(self, data):
        # Validate the entire write before sending anything. Each group ends at
        # a command boundary; SYNC must never become part of a fragmented line.
        lines = data.splitlines(keepends=True)
        if not data.endswith(b'\n') or any(not line.endswith(b'\n') or len(line)>96
                or b'\r' in line or any(ch<32 or ch>126 for ch in line[:-1]) for line in lines):
            raise SerialLinkError('BLE: expected complete ASCII protocol lines (max 95 bytes)')
        # Up to six ordinary ATT fragments, below the eight-slot firmware RX
        # queue. Reserve the longest SYNC footer; never use a prepared write.
        return list(command_groups(data, self.command_capacity))

    @property
    def command_capacity(self):
        return 6*self.write_size-16 if self._application_ack else self.write_size

    def configure(self, data):
        validate_configuration(data)
        for group in command_groups(data, self.command_capacity):
            self.write(group)

    def _check(self):
        if self._error:
            raise self._error
        if self._closed:
            raise SerialLinkError('BLE: disconnected')

    @property
    def in_waiting(self):
        self._check()
        with self._lock:
            return len(self._buffer)

    def read(self, count):
        self._check()
        with self._lock:
            data = bytes(self._buffer[:count]); del self._buffer[:count]
            return data

    async def _write(self, data, trace=None):
        if trace: trace.mark('ble_loop')
        async with self._write_lock:
            if trace: trace.mark('lock_acquired')
            if getattr(self, '_application_ack', False):
                groups = self._ack_groups(data)
                try:
                    for group in groups:
                        await self._ack_exchange(group, trace)
                except Exception:
                    # One best-effort safety STOP, no replay of musical data.
                    # Missing ACK is still a failed/unknown session, never success.
                    with contextlib.suppress(Exception):
                        await asyncio.wait_for(self._client.write_gatt_char(
                            RX, b'ALL STOP\n', response=False), .1)
                    raise
                if trace: trace.mark('completed')
                return
            # Use negotiated capacity; retain acknowledged writes and framing.
            for offset in range(0, len(data), self.write_size):
                if trace: trace.mark('gatt_started')
                await self._client.write_gatt_char(RX, data[offset:offset+self.write_size], response=True)
                if trace: trace.fragment_finished()
        if trace: trace.mark('completed')

    def timing_snapshot(self):
        return {**self._write_history.snapshot(),
                'deliveryMode':'execution-ack' if getattr(self,'_application_ack',False) else 'att-response',
                'bleLoop':self._loop_timing.snapshot() if hasattr(self,'_loop_timing') else None}

    def upload_firmware(self, image, key, on_progress=None):
        self._check()
        if not getattr(self,'supports_ota',False):
            raise SerialLinkError('Firmware bez BLE OTA; wgraj obsługę raz przez USB')
        async def transfer():
            async with self._write_lock:
                return await ble_ota.upload(self._client,image,key,on_progress)
        future=asyncio.run_coroutine_threadsafe(transfer(),self._loop)
        try:return future.result(timeout=930)
        except BaseException:
            future.cancel()
            raise

    def write(self, data):
        self._check()
        trace = self._write_history.add(data)
        coroutine = self._write(data, trace)
        future = None
        try:
            future = asyncio.run_coroutine_threadsafe(coroutine, self._loop)
            future.result(timeout=2)
        except Exception as exc:
            trace.fail(exc)
            if future is not None: future.cancel()
            else: coroutine.close()
            self._error = SerialLinkError(f'BLE write: {exc}')
            self.close()
            raise self._error from exc
        return len(data)

    def close(self):
        self._closed = True
        if self._loop.is_running():
            if hasattr(self, '_end'):
                self._loop.call_soon_threadsafe(self._end.set)
            if hasattr(self, '_task'):
                self._loop.call_soon_threadsafe(self._task.cancel)
            else:
                self._loop.call_soon_threadsafe(lambda: None)
        if threading.current_thread() is not self._thread:
            self._thread.join(timeout=2)


class GatewayBytes:
    """Docker-to-native BLE bridge; plain command bytes after connection header."""
    def __init__(self, address):
        self._error_probe = b''
        self._configuration_buffer = bytearray()
        self._write_lock = threading.Lock()
        host, port = address.rsplit(':', 1)
        self._socket = socket.create_connection((host, int(port)), timeout=2)
        try:
            self._socket.settimeout(20)
            header = bytearray()
            while not header.endswith(b'\n') and len(header) < 1024:
                chunk = self._socket.recv(1)
                if not chunk: break
                header.extend(chunk)
            if bytes(header) not in (b'BLE CONNECTED\n', b'BLE CONNECTED ota=1\n'):
                raise SerialLinkError(header.decode(errors='replace').strip() or 'BLE bridge disconnected')
            self.supports_ota = b'ota=1' in header
            self._socket.settimeout(2)
        except Exception:
            self.close()
            raise

    @property
    def in_waiting(self):
        if getattr(self, '_configuration_buffer', None):
            return len(self._configuration_buffer)
        return 65536 if select.select([self._socket], [], [], 0)[0] else 0

    def read(self, count):
        if getattr(self, '_configuration_buffer', None):
            data = bytes(self._configuration_buffer[:count])
            del self._configuration_buffer[:count]
        else:
            data = self._socket.recv(count)
        if not data:
            raise SerialLinkError('BLE: disconnected')
        # Gateway errors may span TCP packets. Surface them as transport errors
        # so the engine pauses instead of ignoring them as firmware telemetry.
        probe = self._error_probe + data
        if b'BLE ERROR ' in probe:
            raise SerialLinkError(probe.split(b'BLE ERROR ', 1)[1].decode(errors='replace').strip())
        self._error_probe = probe[-10:]
        return data

    def write(self, data):
        try:
            with self._write_lock:
                self._socket.sendall(data)
        except OSError as exc:
            raise SerialLinkError(f'BLE bridge write: {exc}') from exc
        return len(data)

    def configure(self, data):
        """Await setup execution before sending STATUS, HOME or song commands."""
        validate_configuration(data)
        with self._write_lock:
            self._request(f'GATEWAY CONFIG {len(data)}'.encode('ascii'), data, b'BLE CONFIGURED', timeout=5)

    def _request(self, header, data, expected, *, timeout=2):
        """Called under write ownership; preserve interleaved firmware telemetry."""
        self._socket.sendall(header+b'\n'+data)
        deadline = time.monotonic()+timeout
        try:
            while True:
                line = bytearray()
                while not line.endswith(b'\n'):
                    remaining = deadline-time.monotonic()
                    if remaining <= 0:
                        raise SerialLinkError('BLE gateway execution confirmation timeout')
                    self._socket.settimeout(min(2, remaining))
                    chunk = self._socket.recv(1)
                    if not chunk:
                        raise SerialLinkError('BLE gateway disconnected before execution confirmation')
                    line.extend(chunk)
                    if len(line) > 4096:
                        raise SerialLinkError('BLE gateway invalid reply')
                if line == expected+b'\n':
                    return
                if line.startswith((b'BLE ERROR ', b'ERR ')):
                    raise SerialLinkError(line.decode('ascii', errors='replace').strip())
                if len(self._configuration_buffer)+len(line) > 65536:
                    raise SerialLinkError('BLE gateway RX overflow')
                self._configuration_buffer.extend(line)
        finally:
            self._socket.settimeout(2)

    def upload_firmware(self, image, key, on_progress=None):
        if not getattr(self,'supports_ota',False):raise SerialLinkError('Firmware bez BLE OTA; pierwsze wgranie przez USB')
        if len(key)!=32 or not 1<=len(image)<=ble_ota.MAX_IMAGE:raise ValueError('Invalid OTA payload')
        with self._write_lock:
            self._socket.settimeout(15)
            def line():
                data=bytearray()
                while not data.endswith(b'\n') and len(data)<4096:
                    chunk=self._socket.recv(1)
                    if not chunk:raise SerialLinkError('BLE OTA: gateway disconnected')
                    data.extend(chunk)
                text=data.decode('ascii').strip()
                if text.startswith(('BLE ERROR ','ERR ')):raise SerialLinkError(text)
                if len(data)>=4096:raise SerialLinkError('BLE OTA invalid reply')
                return text
            try:
                self._socket.sendall(f'GATEWAY OTA {len(image)}\n'.encode('ascii'))
                if line()!='BLE OTA READY':raise SerialLinkError('BLE OTA: missing gateway readiness')
                self._socket.sendall(key+image)
                while True:
                    response=line()
                    if response=='BLE OTA COMPLETE':return {'bytes':len(image)}
                    if response.startswith('BLE OTA PROGRESS '):
                        percent=int(response.rsplit(' ',1)[1])
                        if not 0<=percent<=100:raise SerialLinkError('BLE OTA invalid progress')
                        if on_progress:on_progress(percent)
            finally:self._socket.settimeout(2)

    def close(self):
        self._socket.close()


class BleOrchestraLink(OrchestraLink):
    is_ble = True
    protocol_version = 2
    board = 'esp32'
    transport_kind = 'ble'

    @property
    def supports_ota(self):return getattr(self._serial,'supports_ota',False)

    def upload_firmware(self,image,key,on_progress=None):
        return self._serial.upload_firmware(image,key,on_progress)

    def send_batch(self, commands):
        """One ordered operation; BleBytes locks across all ATT fragments."""
        if any('\n' in command or '\r' in command for command in commands):
            raise ValueError('batch entries must be single protocol lines')
        if commands:
            self._serial.write(('\n'.join(commands) + '\n').encode('ascii'))

    def send_configuration(self, commands):
        self._serial.configure(('\n'.join(commands) + '\n').encode('ascii'))

    def __init__(self, byte_transport=None):
        self.port = 'ble://' + NAME
        self.label = NAME + ' · BLE'
        self._buffer = ''
        self.device_status = {}
        self.controller_status = {}
        self._status_lines = None
        gateway = os.getenv('ORCHESTRA_BLE_GATEWAY')
        self._serial = byte_transport or (GatewayBytes(gateway) if gateway else BleBytes())

    def wait_boot(self, timeout=10, echo=print, **_kwargs):
        # BLE does not receive USB's boot READY. Validate the same protocol via PING.
        self.ping()
        return self.wait_for('PONG', timeout=timeout) == 'PONG'

    def close(self):
        self._serial.close()

    def wait_homed(self, timeout=10, echo=print):
        # BLE STATUS is fragmented/paced: do not request another transaction
        # until the previous one ends. Device readiness/parser are unchanged.
        deadline = time.monotonic() + timeout
        while time.monotonic() < deadline:
            self.status()
            while time.monotonic() < deadline:
                lines = self.poll_lines()
                for line in lines:
                    echo(line)
                    if line.startswith('ERR'): return False
                if 'STATUS END' in lines:
                    fdds = [value for key, value in self.device_status.items() if key.startswith('FDD:') and value.get('enabled') == '1']
                    if any(key.startswith('FDD:') for key in self.device_status) and all(value.get('homed') == '1' and value.get('homing') == '0' for value in fdds):
                        return True
                    break
                time.sleep(.005)
        return False
