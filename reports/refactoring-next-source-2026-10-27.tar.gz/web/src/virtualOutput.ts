import {pulseCoefficients,type SpeakerWaveform} from './pulseWave'
import {mechanicalSamples,type MechanicalArticulation} from './mechanicalAudio'
/** Web Audio executes Player timestamps. It owns audio nodes, never song time. */
export interface Command {
  time:number; device_id:string; kind:'tone'|'hit'|'stop'; duration:number;
  hz:number; velocity:number; articulation?:MechanicalArticulation & {attack?:number; decay?:number; sustain?:number; intensity?:number; resonance?:number; kind?:string; duration?:number;
    gain?:{times:number[];values:number[]}; frequency?:{times:number[];values:number[]}}
}
type Voice={source:OscillatorNode|AudioBufferSourceNode; gain:GainNode; start:number; end:number; device:string;level?:GainNode;levelValue?:number;duty?:number;waveform?:SpeakerWaveform;labHz?:number;legato?:boolean}
export class VirtualOutput {
  context:AudioContext|null=null
  private voices:Voice[]=[]
  private bus:GainNode|null=null
  private epoch=-1
  private offset:number|null=null
  private lastHeartbeat=0
  private watchdog:ReturnType<typeof setInterval>|null=null
  constructor(private now=()=>performance.now()/1000) {}
  resetSession(){
    // Epochs and clock samples belong to one backend session. Keep the user's
    // unlocked AudioContext, but never carry old scheduled voices into hello.
    this.stop();this.epoch=-1;this.offset=null;this.lastHeartbeat=0
  }
  async unlock() {
    this.context??=new AudioContext()
    await this.context.resume()
    if(this.context.state!=='running') throw new Error('Przeglądarka nie uruchomiła Web Audio')
    if(!this.bus){this.bus=this.context.createGain();this.bus.connect(this.context.destination)}
    this.heartbeat()
    this.watchdog??=setInterval(()=>{if(this.now()-this.lastHeartbeat>.5)this.stop()},50)
  }
  private heartbeat(){
    this.lastHeartbeat=this.now()
    if(this.context&&this.bus){const now=this.context.currentTime;this.bus.gain.cancelScheduledValues(now);this.bus.gain.setValueAtTime(1,now);this.bus.gain.setValueAtTime(0,now+.5)}
  }
  sync(sent:number,serverTime:number) {
    const received=this.now()
    // Clock sample uses RTT midpoint, not accumulated UI animation deltas.
    this.offset=serverTime-(sent+received)/2
    this.heartbeat()
  }
  state(epoch:number,playing:boolean) {
    if(epoch<this.epoch)return
    if(epoch>this.epoch || !playing)this.stop()
    this.epoch=epoch
    this.heartbeat()
  }
  private pulse(source:OscillatorNode,amplitude:number){
    if(!this.context)return
    if(amplitude===0){source.type='square';return} // Mix gain silences a zero-duty pulse.
    const {real,imag}=pulseCoefficients(amplitude)
    source.setPeriodicWave(this.context.createPeriodicWave(real,imag,{disableNormalization:true}))
  }
  private setWave(source:OscillatorNode,_waveform:SpeakerWaveform,amplitude:number){
    this.pulse(source,amplitude)
  }
  setVolumes(devices:{id:string;volume:number;realAmplitude?:number;waveform?:SpeakerWaveform}[]) {
    const values=new Map(devices.map(d=>[d.id,d]))
    for(const voice of this.voices){
      const device=values.get(voice.device)
      const duty=device?.realAmplitude??50
      const value=device?(duty===0?0:device.volume):undefined
      const waveform=device?.waveform??'pulse'
      if(voice.level&&(voice.duty!==duty||voice.waveform!==waveform)&&'setPeriodicWave' in voice.source){
        this.setWave(voice.source,waveform,duty);voice.duty=duty;voice.waveform=waveform
      }
      if(voice.level&&value!==undefined&&value!==voice.levelValue){
        const now=this.context?.currentTime??0
        const at=Math.max(now,voice.start)
        // Silence active and queued voices immediately; cancel future gain too.
        voice.level.gain.cancelScheduledValues(value===0?now:at)
        if(value===0)voice.level.gain.setValueAtTime(0,now)
        else {
          voice.level.gain.setValueAtTime(voice.levelValue??value,at)
          voice.level.gain.linearRampToValueAtTime(value,at+.01)
        }
        voice.levelValue=value
      }
    }
  }
  stop(device?:string) {
    for(const voice of [...this.voices])if(!device || voice.device===device) {
      try { voice.gain.gain.cancelScheduledValues(0); voice.gain.gain.setValueAtTime(0,this.context?.currentTime??0); voice.source.stop() } catch { /* already ended */ }
      voice.source.disconnect(); voice.gain.disconnect();voice.level?.disconnect()
      this.voices=this.voices.filter(v=>v!==voice)
    }
  }
  schedule(packet:{epoch:number;origin:number;serverTime:number;commands:Command[]}, devices:Record<string,{volume:number;type:string;realAmplitude?:number;waveform?:SpeakerWaveform}>) {
    const ctx=this.context
    if(packet.epoch<this.epoch)return
    if(!ctx || ctx.state!=='running')throw new Error('Wyjście Web Audio nie działa')
    if(packet.epoch>this.epoch){this.stop();this.epoch=packet.epoch}
    this.offset??=packet.serverTime-this.now()
    const serverNow=this.now()+this.offset
    for(const c of packet.commands){
      const when=ctx.currentTime+packet.origin+c.time-serverNow
      if(c.kind==='stop'){
        for(const v of this.voices)if(v.device===c.device_id && v.start<=when+.001){
          const at=Math.max(ctx.currentTime,when)
          v.gain.gain.cancelScheduledValues(at);v.gain.gain.setValueAtTime(0,at)
          try{v.source.stop(at)}catch{/* already stopped */}
          v.end=at;v.legato=false
        }
        continue
      }
      const end=when+c.duration
      if(end<=ctx.currentTime || (c.kind==='hit'&&ctx.currentTime-when>.1))continue
      const start=Math.max(ctx.currentTime,when)
      if(c.kind==='tone'&&(c.articulation?.kind==='laboratory'||c.articulation?.kind==='fdd_legato')){
        this.liveTone(c,devices[c.device_id],start,end)
        continue
      }
      for(const v of this.voices)if(v.device===c.device_id && v.end>start && v.start<=start){
        v.gain.gain.cancelScheduledValues(start);v.gain.gain.setValueAtTime(0,start)
        try{v.source.stop(start)}catch{/* ended */}
      }
      const gain=ctx.createGain(),device=devices[c.device_id],a=c.articulation
      const mechanical=device?.type!=='VHS'
      let source:OscillatorNode|AudioBufferSourceNode
      if(mechanical){
        const samples=mechanicalSamples(device?.type??'FDD',c.device_id,c.hz,c.duration,ctx.sampleRate,a)
        const buffer=ctx.createBuffer(1,samples.length,ctx.sampleRate);buffer.copyToChannel(samples,0)
        source=ctx.createBufferSource();source.buffer=buffer
      } else {
        source=ctx.createOscillator();this.setWave(source,device?.waveform??'pulse',device?.realAmplitude??50);source.frequency.setValueAtTime(c.hz,start)
      }
      // Hardware STEP has no per-note amplitude control. Equal units share the same level.
      const stepper=device?.type==='FDD'||device?.type==='DVD_SLED'
      // Give virtual HDD impacts +6 dB; keep MIDI dynamics and other families unchanged.
      const familyLevel=mechanical ? .22*.6*(device?.type==='HDD_VCM'?2:1) : .045
      const volume=familyLevel*(stepper?1:(a?.intensity??(c.velocity/127)**.65))
      const attack=Math.min(mechanical ? .001 : (a?.attack??.003),(end-start)/4)
      gain.gain.setValueAtTime(0,start)
      gain.gain.linearRampToValueAtTime(volume,start+attack)
      gain.gain.linearRampToValueAtTime(volume*(mechanical?1:(a?.sustain??.15)),Math.min(end,start+attack+(a?.decay??.08)))
      if('frequency' in source && a?.frequency)for(let i=0;i<a.frequency.times.length;i++){
        const at=when+a.frequency.times[i]
        if(at>=start&&at<end)source.frequency.linearRampToValueAtTime(a.frequency.values[i],at)
      }
      // MIDI channel gain/expression curves retain their planned timestamps.
      const expression=ctx.createGain();expression.gain.setValueAtTime(stepper?1:(a?.gain?.values[0]??1),start)
      if(!stepper&&a?.gain)for(let i=0;i<a.gain.times.length;i++){
        const at=when+a.gain.times[i]
        if(at>=start&&at<end)expression.gain.linearRampToValueAtTime(a.gain.values[i],at)
      }
      if(!mechanical&&c.kind!=='tone')gain.gain.linearRampToValueAtTime(0,Math.min(end,start+(a?.duration??.1)))
      gain.gain.setValueAtTime(0,end)
      const level=mechanical?undefined:ctx.createGain()
      const levelValue=(device?.realAmplitude??50)===0?0:(device?.volume??.5)
      if(level){level.gain.setValueAtTime(levelValue,start);expression.connect(level);level.connect(this.bus??ctx.destination)}
      else expression.connect(this.bus??ctx.destination)
      source.connect(gain);gain.connect(expression)
      const voice={source,gain,start,end,device:c.device_id,level,levelValue,duty:device?.realAmplitude??50,waveform:device?.waveform??'pulse' as SpeakerWaveform};this.voices.push(voice)
      source.onended=()=>{source.disconnect();gain.disconnect();expression.disconnect();level?.disconnect();this.voices=this.voices.filter(v=>v!==voice)}
      if('buffer' in source)source.start(start,Math.max(0,start-when))
      else source.start(start)
      source.stop(end)
    }
  }
  private liveTone(c:Command,device:{volume:number;type:string;realAmplitude?:number},start:number,end:number){
    const ctx=this.context!
    const legato=c.articulation?.kind==='fdd_legato'
    const existing=this.voices.find(v=>v.device===c.device_id&&v.labHz!==undefined&&v.legato===legato&&
      (v.end>start||legato&&Math.abs(v.end-start)<=1e-9))
    if(existing){
      if('buffer' in existing.source){
        if(legato)existing.source.playbackRate.setValueAtTime(c.hz/existing.labHz!,start)
        else existing.source.playbackRate.linearRampToValueAtTime(c.hz/existing.labHz!,start)
      }
      else existing.source.frequency.linearRampToValueAtTime(c.hz,start)
      existing.end=end
      existing.source.stop(end) // Refresh a bounded audio lease, without reattacking.
      return
    }
    const gain=ctx.createGain(),mechanical=device.type!=='VHS'
    let source:OscillatorNode|AudioBufferSourceNode
    if(mechanical){
      // Loop complete periods after the model's startup transient. Live pitch
      // scales this preview buffer; it is not an acoustic hardware calibration.
      const cycles=Math.max(4,Math.ceil(c.hz*.1)),length=Math.min(Math.round(ctx.sampleRate*.25),Math.max(2,Math.round(cycles/c.hz*ctx.sampleRate)))
      const warmup=Math.ceil(ctx.sampleRate*.03)
      const samples=mechanicalSamples(device.type,c.device_id,c.hz,(length+warmup+200)/ctx.sampleRate,ctx.sampleRate)
      const buffer=ctx.createBuffer(1,length,ctx.sampleRate);buffer.copyToChannel(samples.slice(warmup,warmup+length),0)
      const node=ctx.createBufferSource();node.buffer=buffer;node.loop=true;source=node
    }else{
      const node=ctx.createOscillator();this.pulse(node,device.realAmplitude??50);node.frequency.setValueAtTime(c.hz,start);source=node
    }
    const level=mechanical?undefined:ctx.createGain(),levelValue=(device.realAmplitude??50)===0?0:device.volume
    gain.gain.setValueAtTime(0,start);gain.gain.linearRampToValueAtTime(mechanical?.132:.045,start+.005)
    source.connect(gain)
    if(level){level.gain.setValueAtTime(levelValue,start);gain.connect(level);level.connect(this.bus??ctx.destination)}
    else gain.connect(this.bus??ctx.destination)
    const voice:Voice={source,gain,start,end,device:c.device_id,level,levelValue,duty:device.realAmplitude??50,labHz:c.hz,legato}
    this.voices.push(voice)
    source.onended=()=>{source.disconnect();gain.disconnect();level?.disconnect();this.voices=this.voices.filter(v=>v!==voice)}
    source.start(start);source.stop(end)
  }
  close(){this.stop();if(this.watchdog)clearInterval(this.watchdog);this.watchdog=null;void this.context?.close();this.context=null;this.bus=null}
}
